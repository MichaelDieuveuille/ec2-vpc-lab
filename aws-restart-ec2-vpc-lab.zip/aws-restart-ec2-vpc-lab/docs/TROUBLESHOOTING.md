# SSH / PuTTY Troubleshooting Notes

## Symptom

PuTTY would not accept the PPK file used for the lab.

## Isolation

Instead of recreating the EC2 instance, I checked the infrastructure and compared the key formats.

The PEM private key worked, while the PPK used with PuTTY did not.

## Resolution

1. Downloaded the working PEM private key.
2. Opened PuTTYgen.
3. Loaded the PEM key.
4. Saved the key in PuTTY's PPK format.
5. Selected the converted PPK in PuTTY.
6. Retried the SSH connection.

## Assessment

I suspected the original lab PPK was corrupted or otherwise unusable in my Windows/PuTTY workflow. This was an operational assessment rather than a confirmed defect in the training lab.

## Troubleshooting principle

Change one layer at a time and use a known-good comparison whenever possible.
