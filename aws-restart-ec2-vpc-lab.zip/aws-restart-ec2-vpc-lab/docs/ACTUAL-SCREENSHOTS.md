# Actual Lab Screenshots

The repository currently includes original explanatory diagrams rather than fabricated screenshots.

For the final hiring portfolio, add your own screenshots from the actual lab here.

## Recommended screenshots

- `01-vpc.png` — VPC details
- `02-subnet.png` — subnet and public IPv4 setting
- `03-igw.png` — attached Internet Gateway
- `04-route-table.png` — default route
- `05-nacl.png` — inbound/outbound NACL rules
- `06-security-group.png` — HTTP + restricted SSH rules
- `07-ec2.png` — EC2 instance details
- `08-puttygen.png` — PEM loaded into PuTTYgen
- `09-putty.png` — converted PPK selected in PuTTY
- `10-ssh-success.png` — successful Linux shell

## Redaction checklist

Before uploading screenshots, hide:

- AWS account ID
- private IPs if you prefer not to publish them
- public IP addresses if you prefer not to publish them
- usernames
- credentials
- access keys
- private keys
- tokens
- any unrelated personal information
