# AWS VPC & EC2 Infrastructure Lab

![AWS](https://img.shields.io/badge/AWS-Cloud-orange)
![EC2](https://img.shields.io/badge/AWS-EC2-blue)
![VPC](https://img.shields.io/badge/AWS-VPC-purple)
![Linux](https://img.shields.io/badge/Linux-Amazon%20Linux-black)
![Networking](https://img.shields.io/badge/Networking-TCP%2FIP-green)
![Status](https://img.shields.io/badge/Project-Completed-success)

> **Portfolio project:** Designed and deployed a public-facing AWS network and Linux EC2 workload while troubleshooting an SSH key-format problem on Windows.

## Executive Summary

This project documents a hands-on AWS infrastructure lab completed as part of AWS re/Start training.

The objective was to build a small public-facing cloud environment **from the network layer upward**, rather than relying on AWS default networking. The environment included a custom VPC, public subnet, Internet Gateway, route table, Network ACL, Security Group, and an Amazon Linux EC2 instance.

A major troubleshooting issue occurred during SSH setup on Windows: the lab-provided `.ppk` key was not accepted by PuTTY. I isolated the problem by testing the `.pem` key, confirmed that the PEM key worked, and converted the PEM key to a new `.ppk` file with PuTTYgen. The converted key allowed PuTTY-based SSH access.

This troubleshooting experience was particularly valuable because it required separating **AWS infrastructure/networking problems from a local SSH credential-format problem**.

## What This Project Demonstrates

- AWS VPC design and segmentation
- IPv4 CIDR planning
- Public subnet configuration
- Internet Gateway attachment
- Route table configuration
- Network ACL configuration
- EC2 deployment
- Security Group configuration
- SSH connectivity
- Linux/Amazon Linux administration
- Windows-to-Linux remote administration
- Structured troubleshooting
- Security-minded access configuration
- Technical documentation

---

## Architecture

![Architecture](docs/images/01-architecture.svg)

### Traffic flow

```text
Internet
   |
   v
Internet Gateway
   |
   v
Public Route Table
   |
   v
PublicSubnet-1 (10.0.1.0/24)
   |
   v
WebServerSG
   |
   v
MyWebServer - Amazon Linux EC2
```

The custom VPC used the `10.0.0.0/16` CIDR range, with `PublicSubnet-1` using `10.0.1.0/24`. The subnet was configured to automatically assign public IPv4 addresses to instances launched within it.

---

# 1. Create the Custom VPC

**Configuration**

| Setting | Value |
|---|---|
| VPC name | `MyCustomVPC` |
| IPv4 CIDR | `10.0.0.0/16` |

![VPC creation](docs/images/02-vpc-creation.svg)

### Why

A custom VPC provides an isolated network boundary where routing and access controls can be explicitly designed.

The lab emphasized building the network manually so the relationship between VPCs, subnets, routing, gateways, and firewalls could be understood rather than hidden behind default configurations.

---

# 2. Create the Public Subnet

**Configuration**

| Setting | Value |
|---|---|
| Subnet | `PublicSubnet-1` |
| VPC | `MyCustomVPC` |
| Availability Zone | `us-east-1a`* |
| IPv4 CIDR | `10.0.1.0/24` |
| Auto-assign public IPv4 | Enabled |

\*Availability Zone can vary by deployment.

![Subnet](docs/images/03-subnet.svg)

### Why

The subnet creates a smaller network segment inside the VPC. Enabling automatic public IPv4 assignment allows an EC2 instance in this public subnet to receive a public address for remote access.

---

# 3. Create and Attach the Internet Gateway

**Configuration**

| Setting | Value |
|---|---|
| Internet Gateway | `MyIGW` |
| Attached VPC | `MyCustomVPC` |

![Internet Gateway](docs/images/04-internet-gateway.svg)

An Internet Gateway provides the VPC with a path to and from the internet when routing and instance-level access controls also permit the traffic.

---

# 4. Configure the Public Route Table

**Configuration**

| Setting | Value |
|---|---|
| Route table | `PublicRouteTable` |
| VPC | `MyCustomVPC` |
| Destination | `0.0.0.0/0` |
| Target | `MyIGW` |
| Associated subnet | `PublicSubnet-1` |

![Route table](docs/images/05-route-table.svg)

### Key concept

Attaching an Internet Gateway alone does not make a subnet public. The subnet needs a route such as:

```text
0.0.0.0/0 -> Internet Gateway
```

The route table was then associated with `PublicSubnet-1`.

---

# 5. Configure the Network ACL

The custom NACL was configured as a subnet-level, stateless traffic control layer.

### Inbound

| Rule | Protocol/Port | Source | Action |
|---|---|---|---|
| 100 | HTTP / TCP 80 | `0.0.0.0/0` | Allow |
| 110 | SSH / TCP 22 | My IP | Allow |
| 120 | TCP 1024-65535 | `0.0.0.0/0` | Allow |

### Outbound

| Rule | Protocol/Port | Destination | Action |
|---|---|---|---|
| 100 | HTTP / TCP 80 | `0.0.0.0/0` | Allow |
| 110 | HTTPS / TCP 443 | `0.0.0.0/0` | Allow |
| 120 | TCP 1024-65535 | `0.0.0.0/0` | Allow |

Because NACLs are stateless, return traffic must be explicitly permitted.

---

# 6. Configure the EC2 Security Group

**Security Group:** `WebServerSG`

### Inbound rules

| Type | Port | Source |
|---|---:|---|
| HTTP | 80 | `0.0.0.0/0` |
| SSH | 22 | My IP |

![Security Group](docs/images/06-security-group.svg)

### Security decision

HTTP was open to the internet because the workload was intended to be publicly reachable.

SSH was restricted to **My IP** instead of opening TCP/22 to the entire internet.

> **Portfolio note:** If this project is reproduced, use the current public IP of the administrator and avoid `0.0.0.0/0` for SSH unless there is a specific, documented reason.

---

# 7. Launch the EC2 Instance

**Configuration**

| Setting | Value |
|---|---|
| Name | `MyWebServer` |
| AMI | Amazon Linux 2023 |
| Instance type | `t2.micro` or region-equivalent small instance |
| VPC | `MyCustomVPC` |
| Subnet | `PublicSubnet-1` |
| Public IPv4 | Enabled |
| Security Group | `WebServerSG` |
| Key format initially selected | `.pem` |

![EC2 instance](docs/images/07-ec2-instance.svg)

The EC2 instance served as the cloud-hosted Linux server for the lab.

---

# 8. SSH Connection Attempt from Windows

The intended Windows workflow was:

```text
Windows PC
    |
    v
PuTTY
    |
    v
Private key (.ppk)
    |
    v
EC2 public IP
    |
    v
Amazon Linux
```

![SSH flow](docs/images/08-ssh-flow.svg)

The SSH connection is encrypted and provides command-line access for server administration.

---

# 9. Troubleshooting: PuTTY Did Not Accept the Lab PPK

## Problem

The `.ppk` file supplied/used for the lab was not accepted by PuTTY on the Windows machine.

The important troubleshooting decision was **not to immediately rebuild the EC2 instance**. Instead, I isolated the problem to the SSH key.

### Investigation

```text
EC2 instance
   |
   +--> Running? YES
   |
   +--> Network configuration? Configured
   |
   +--> Public IP? Available
   |
   +--> Security Group SSH rule? Configured
   |
   +--> PEM key? Works
   |
   +--> Lab PPK? Not accepted by PuTTY
```

This pointed toward a key-format/file problem rather than an EC2 or VPC deployment problem.

![PPK troubleshooting](docs/images/09-ppk-troubleshooting.svg)

### Root-cause assessment

I **suspected the lab-provided PPK file was corrupted or otherwise unusable in my Windows/PuTTY workflow**. I did not treat this as a confirmed AWS-side defect.

The `.pem` private key worked correctly, which provided a strong comparison point.

---

# 10. Resolution: Convert PEM to PPK with PuTTYgen

I downloaded the working PEM private key and used **PuTTYgen** to convert it into a PuTTY-compatible `.ppk` file.

### Workflow

```text
Working PEM
    |
    v
PuTTYgen
    |
    v
Load PEM key
    |
    v
Save private key
    |
    v
New PPK
    |
    v
PuTTY
    |
    v
SSH to EC2
```

![PEM to PPK](docs/images/10-pem-to-ppk.svg)

### Why this worked

PuTTY uses its own private-key format (`.ppk`) for its key-loading workflow. Converting the working PEM key produced a PPK file that PuTTY could use.

### Troubleshooting lesson

The key insight was:

> **Test each layer independently before rebuilding infrastructure.**

The AWS infrastructure did not need to be recreated. The issue was isolated to the client-side SSH key file/format.

---

# 11. Final Connectivity

After converting the working PEM key to PPK:

```text
Windows
   |
PuTTY
   |
Converted .PPK
   |
Internet
   |
Internet Gateway
   |
Route Table
   |
Public Subnet
   |
Security Group
   |
EC2
   |
Amazon Linux
```

![Successful connection](docs/images/11-successful-ssh.svg)

The converted key enabled the Windows/PuTTY SSH workflow to the EC2 instance.

---

# Troubleshooting Methodology

This project reinforced a repeatable cloud-support troubleshooting process:

### Layer 1 — Client

- Is the correct key file being used?
- Is the key in a format supported by the SSH client?
- Is PuTTY configured correctly?

### Layer 2 — Network

- Does the instance have a public IP?
- Is the subnet public?
- Is the route table configured?
- Is the Internet Gateway attached?

### Layer 3 — AWS Security

- Does the Security Group allow TCP/22?
- Is SSH restricted to the correct source IP?
- Is the NACL allowing both required directions?

### Layer 4 — Server

- Is the EC2 instance running?
- Is SSH available on the server?
- Is the correct username being used?

This layered approach prevents unnecessary changes and helps isolate the actual failure domain.

---

# Security Considerations

This lab was intentionally simple, but several security practices were applied:

- SSH restricted to the administrator's IP instead of `0.0.0.0/0`
- Separate subnet-level NACL and instance-level Security Group controls
- Key-based SSH authentication
- No private keys stored in this repository
- No credentials, access keys, or secrets committed to GitHub

## Important

**Never upload `.pem` or `.ppk` private keys to GitHub.**

This repository intentionally contains no private keys.

If a private key is accidentally exposed, treat it as compromised and rotate/revoke the associated access immediately.

---

# Key Lessons Learned

## 1. AWS networking is layered

Internet access depends on multiple components working together:

```text
VPC
 ↓
Subnet
 ↓
Route Table
 ↓
Internet Gateway
 ↓
Security Controls
 ↓
EC2
```

## 2. Security Groups and NACLs are different

- Security Groups are associated with network interfaces/instances and are stateful.
- NACLs operate at the subnet level and are stateless.

## 3. SSH failures are not always AWS problems

A connection failure can originate from:

- the client
- private-key format
- PuTTY configuration
- routing
- Security Groups
- NACLs
- the EC2 host
- SSH configuration

## 4. Don't rebuild before isolating

The EC2 instance did not need to be recreated. Testing the working PEM key helped isolate the problem to the PPK/client side.

## 5. Documentation is part of infrastructure work

Recording the symptom, investigation, root-cause assessment, resolution, and lesson learned turns a lab into evidence of troubleshooting ability.

---

# Skills Demonstrated

**Cloud**

- AWS EC2
- AWS VPC
- Internet Gateway
- Route Tables
- Security Groups
- Network ACLs
- Public IPv4 networking

**Networking**

- IPv4 CIDR
- Subnets
- Routing
- TCP/IP
- TCP/22 SSH
- TCP/80 HTTP
- Ephemeral ports

**Systems**

- Amazon Linux
- SSH
- PuTTY
- PuTTYgen
- Windows-to-Linux administration

**Troubleshooting**

- Layered troubleshooting
- Connectivity isolation
- Key-format troubleshooting
- Root-cause analysis
- Technical documentation

---

# Evidence

The `docs/images/` directory contains original portfolio diagrams illustrating the architecture and troubleshooting sequence.

For a stronger portfolio, add your **actual AWS Console screenshots** to this section after redacting:

- public IP addresses
- account IDs
- usernames
- key names if sensitive
- credentials/secrets

Recommended screenshots:

1. VPC details
2. Subnet details
3. Internet Gateway attached to VPC
4. Route table with `0.0.0.0/0`
5. NACL rules
6. Security Group rules
7. EC2 instance details
8. PuTTY configuration showing the converted PPK selected
9. PuTTYgen conversion step
10. Successful SSH terminal

---

# Future Improvements

This project can be extended into a more production-oriented architecture by adding:

- Private subnets
- NAT Gateway
- Application Load Balancer
- Auto Scaling
- RDS
- CloudWatch monitoring
- CloudTrail
- IAM roles
- HTTPS/TLS
- Terraform Infrastructure as Code
- automated deployment

---

## Portfolio Positioning

This project is designed to demonstrate **hands-on cloud infrastructure and troubleshooting**, not simply AWS service familiarity.

A concise resume description could be:

> **AWS VPC & EC2 Infrastructure Lab** — Designed and deployed a custom AWS VPC with public subnet, Internet Gateway, route table, NACL, Security Group, and Amazon Linux EC2 instance; configured SSH access from Windows and troubleshot a PuTTY private-key compatibility issue by converting a working PEM key to PPK using PuTTYgen.

---

## Disclaimer

This repository documents a training/lab environment completed during AWS re/Start. Resource names and configuration values reflect the documented lab procedure and may differ from a production deployment.

